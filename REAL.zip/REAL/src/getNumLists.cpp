#include "getNumLists.hpp"

unsigned int getNumLists()
{
	// (4 choose 2) = 6
        return 6;
}
