#if ! defined(FASTFILEDECODERBASE_HPP)
#define FASTFILEDECODERBASE_HPP

struct FastFileDecoderBase
{
	static unsigned int const default_blocksize = 64*1024;
};
#endif
