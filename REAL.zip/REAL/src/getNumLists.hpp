#if ! defined(GETNUMLISTS_HPP)
#define GETNUMLISTS_HPP

unsigned int getNumLists();
#endif
